# -*- coding: utf-8 -*-

from . import appoitment_wizard
from . import appoitment_wizard_inherit
from . import patient_id_card_wiz
