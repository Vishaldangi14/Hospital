# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class PatientAppoitment(models.TransientModel):
    # _name = "patient.appoitment"
    _inherit = "patient.appoitment"


    note = fields.Text(string='Description')
    review = fields.Char(string="Review")

    def create_appoitment(self, vals={}):
        vals.update({
            'note': self.note,
        })
        return super().create_appoitment(vals)
