# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class PatientAppoitment(models.TransientModel):
    _name = "patient.appoitment"
    _description = "Patient Appointment"


    patient_id = fields.Many2one('hospital.patient', string="Patient", required=True)
    doctor_id = fields.Many2one('hospital.doctor', string="Doctor", required=True)
    date_appointment = fields.Date(string="Date")
    date_checkup = fields.Datetime(string="Check Up Time")

    def create_appoitment(self, vals={}):
        vals.update({
            'patient_id': self.patient_id.id,
            'doctor_id': self.doctor_id.id,
            'date_appointment': self.date_appointment,
            'date_checkup': self.date_checkup,
        })
        appointment = self.env['hospital.appointment'].sudo().create(vals)
        return {'type': 'ir.actions.act_window_close'}
