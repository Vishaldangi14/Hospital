# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class PatientIdCard(models.TransientModel):
    _name = "patient.id.card"
    _description = "Patient Id Card"

    birthdate_date = fields.Date(string='Birthdate Date', required=True)

    def print_patient_id(self):
        if self.birthdate_date:
            data = {}
            data["birthdate_date"] = self.birthdate_date
            datas = {
                "ids": [],
                "model": "hospital.patient",
                "form": data,
            }
            return self.env.ref(
                "hospital.action_report_saleorder"
            ).report_action([], data=datas)
