# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import tools
from odoo import api, fields, models


class HospitalAppointmentReport(models.Model):
    _name = "hospital.appointment.report"
    _description = "Hospital Appointment Report"
    _auto = False
    _order = 'date_appointment desc'

    name = fields.Char('Order Reference', readonly=True)
    patient_id = fields.Many2one('hospital.patient', readonly=True)
    age = fields.Integer('Age',readonly=True)
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ], "Gender",readonly=True)
    state = fields.Selection([('draft', 'Draft'), ('confirm', 'Confirmed'),
                              ('done', 'Done'), ('cancel', 'Cancelled')], default='draft',
                             string="Status",readonly=True)
    date_appointment = fields.Date("Date",readonly=True)
    date_checkup = fields.Datetime("Check Up Time",readonly=True)

    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        self.env.cr.execute(""" CREATE or REPLACE VIEW hospital_appointment_report AS (
            SELECT
                coalesce(h_appointment.id) as id,
                h_appointment.name as name,
                h_appointment.patient_id as patient_id,
                h_appointment.age as age,
                h_appointment.gender as gender,
                h_appointment.state as state,
                h_appointment.date_appointment as date_appointment,
                h_appointment.date_checkup as date_checkup
            FROM
                hospital_appointment as h_appointment
            LEFT JOIN
                hospital_patient as h_patient ON h_patient.id = h_appointment.patient_id
            GROUP BY
                h_appointment.patient_id,
                h_appointment.name,
                h_appointment.age,
                h_appointment.gender,
                h_appointment.date_appointment,
                h_appointment.date_checkup,
                h_appointment.state,
                h_appointment.id

        )""")



    #     # self.env.cr.execute("""CREATE or REPLACE VIEW %s as (%s)""" % (self._table, query))
