#  See LICENSE file for full copyright and licensing details.
from odoo import api, models


class PatientIdCardParser(models.AbstractModel):
    _name = "report.hospital.report_patient_id_card"
    _description = "Patient Id Card"

    @api.model
    def _get_report_values(self, docids, data=None):
        patient_obj = self.env["patient.id.card"]
        wiz_data = patient_obj.browse(self.env.context.get("active_ids", []))
        patient_ids = self.env['hospital.patient'].search([('birthdate_date','=',wiz_data.birthdate_date)])
        return {
            "doc_ids": [],
            "doc_model": "hospital.patient",
            "docs": patient_ids,
            "passenger": patient_ids,
        }
