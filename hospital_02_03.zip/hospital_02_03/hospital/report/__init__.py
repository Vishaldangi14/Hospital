from . import appointment_psql_report
from . import pars_id_patient