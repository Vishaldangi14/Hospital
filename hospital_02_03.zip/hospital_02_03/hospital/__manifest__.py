{
    'name': 'Hospital management',
    'version': '15.0.1.0.2',
    'summary': 'Hospital Management',
    'description': """Odoo 15 Development Tutorials""",
    'category': 'Tutorials',
    'license': 'AGPL-3',
    'depends': ['base','sale','sale_stock','product','sales_team'],
    'data': [
        'security/ir.model.access.csv',
        'data/data.xml',
        'data/sale_demo.xml',
        'data/hospital.doctor.csv',
        'views/appointment_view.xml',
        'views/hospital_doctor_views.xml',
        'wizard/appoitment_wizard.xml',
        'wizard/appoitment_wizard_inherit.xml',
        'views/patient_views.xml',
        'report/appointment_psql_report_action.xml',
        'report/patient_id_card.xml',
        'wizard/patient_id_card_wiz_views.xml'
    ],
    'demo': [
        'demo/demo.xml'
    ],
    'installable': True,
    'application': True,
}
