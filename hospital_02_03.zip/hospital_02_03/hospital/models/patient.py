# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
from dateutil.relativedelta import relativedelta

class HospitalPatient(models.Model):
    _name = "hospital.patient"
    _description = "Hospital Patient"

    name = fields.Char(string='Name', required=True)

    doctor_id = fields.Many2one('hospital.doctor', string="Doctor")
    doctor_phone = fields.Char(related='doctor_id.phone', string='Phone')
    birthdate_date = fields.Date(string='Birthdate Date')
    age = fields.Integer("Age", compute='_compute_age')
    notes = fields.Text(string='Notes')
    appointment_count = fields.Integer(string='Appointment', compute='_get_appointment_count')

    def _get_appointment_count(self):
        for record in self:
            record.appointment_count = self.env['hospital.appointment'].search_count([('patient_id', '=', record.id)])

    def xyz(self,date):
        print('66666666',date)
        patient_ids = self.env['hospital.patient'].search([('birthdate_date','=',date)])
        return len(patient_ids)

    @api.depends('birthdate_date')
    def _compute_age(self):
        for patient in self:
            if not patient.birthdate_date:
                patient.age = 0
            else:
                patient.age = relativedelta(fields.Date.today(), patient.birthdate_date).years

    @api.onchange('doctor_id')
    def _onchange_doctor_id(self):
        for patient in self:
            # if patient.name:
            #     patient.notes = "Test 2 " + patient.name
            if patient.doctor_id:
                patient.notes = patient.doctor_id.phone + ' Test '

    # @api.onchange('doctor_id')
    # def _onchange_doctor_id(self):
    #         for patient in self:
    #             if patient.doctor_id:
    #                 patient.notes = 'not last dummy message ' + patient.doctor_id.phone
